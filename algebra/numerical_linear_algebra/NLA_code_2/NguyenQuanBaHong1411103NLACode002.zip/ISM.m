% Excercise 1
function [x1,x2]=ISM(f,a,b,N)
d=(b-a)/N;
x1=a;
x2=a+d;
while(subs(f,x1)*subs(f,x2)>0)
    x1=x2;
    x2=x2+d;
    if abs(x2-b)<1e-6
        fscanf('0 root in [%.8f,%.8f]',a,b);
        break
    end
end