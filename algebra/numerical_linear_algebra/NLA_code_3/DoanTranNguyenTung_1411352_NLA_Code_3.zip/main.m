format long
clear all
close all
clc

% Exercise 1
U=[1 1 1 1 ;
    1 2 1 1 ;
    1 1 3 1]
% The rows of U are linearly independent vectors
V=GS(U)
% Checking for orthogonality
dot(V(1,:),V(2,:))
dot(V(2,:),V(3,:))
dot(V(1,:),V(3,:))

% Exercise 2
A=[3 0 ; 0 -2]
[U,E,V]=svd(A)

% Ploting left singular vector
plotrows(U',E)
title('Left singular vectors')
% Ploting right singular vector
plotrows(V,eye(2))
title('Right singular vectors')