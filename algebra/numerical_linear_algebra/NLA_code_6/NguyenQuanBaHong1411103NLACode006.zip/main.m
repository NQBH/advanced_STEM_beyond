clear all 
close all
clc
format long

% Exercise 9.3, Trefethen, NLA.
% a
A = zeros(15,40);
% H
A(2:9,2:3) = ones(8,2);
A(5:6,4:5) = ones(2,2);
A(2:9,6:7) = ones(8,2);
% E
A(3:10,10:11) = ones(8,2);
A(3:4,12:15) = ones(2,4);
A(6:7,12:15) = ones(2,4);
A(9:10,12:15) = ones(2,4);
% L
A(4:11,18:19) = ones(8,2);
A(10:11,20:23) = ones(2,4);
% L
A(5:12,26:27) = ones(8,2);
A(11:12,28:31) = ones(2,4);
% O
A(6:13,34:35) = ones(8,2);
A(6:7,36:37) = ones(2,2);
A(12:13,36:37) = ones(2,2);
A(6:13,38:39) = ones(8,2);
figure(1)
spy(A)
% b
s = svd(A)
figure(2)
plot(s)
figure(3)
semilogy(s)
r = rank(A)
% c
[U,S,V] = svd(A);
B = zeros(15,40);
for j = 1:r
    B = B + s(j)*U(:,j)*V(:,j)';     
end
figure(4)
pcolor(B)
colormap(gray)
axis ij
str = sprintf('iteration = 10');
title(str)
