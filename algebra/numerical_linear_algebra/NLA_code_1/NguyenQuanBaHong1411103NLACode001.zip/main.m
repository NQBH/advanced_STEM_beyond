clear all
close all
clc
format long

A = magic(3)
det(A)
determinant(A)

B=randsymmat(4)

C=randorthomat(4)
C'*C
C'*C-C*C'
