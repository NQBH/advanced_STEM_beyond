clc
close all
clear all
format long
%% 11.2.a
a=1;
b=2;
K=101;
error=zeros(1,K-1);
for N=2:K
    h=(b-a)/N;
    M=zeros(N+1,3);
    F=zeros(N+1,1);
    for i=1:N+1
        for j=1:3
            M(i,1)=exp(a+(i-1)*h);
            M(i,2)=sin(a+(i-1)*h);
            M(i,3)=gamma(a+(i-1)*h);
        end
        F(i)=1/(a+(i-1)*h);
    end
    x_qr=ls_qr(M,F);
    t=linspace(a,b,100);
    f=t.^-1;
    appro=x_qr(1)*exp(t)+x_qr(2)*sin(t)+x_qr(3)*gamma(t);
    error(N-1)=norm(f-appro);
end

figure
plot(t,f)
hold on
plot(t,appro)
title ('f(x) and its approximation')
legend('f(x)','c1*exp(x)+c2*sin(x)+c3*gamma(x)')
xlabel('x');
ylabel('f(x)');
print('-r300','-djpeg');

figure
plot(error)
title ('Error between f(x) and its approximation')
legend('Error')
xlabel('N');
ylabel('Error in discrete L^2 norm');
print('-r300','-djpeg');
%% 11.2.b
% a=0+1e-8;
% b=1;
% K=101;
% error=zeros(1,K-1);
% for N=2:K
%     h=(b-a)/N;
%     M=zeros(N+1,3);
%     F=zeros(N+1,1);
%     for i=1:N+1
%         for j=1:3
%             M(i,1)=exp(a+(i-1)*h);
%             M(i,2)=sin(a+(i-1)*h);
%             M(i,3)=gamma(a+(i-1)*h);
%         end
%         F(i)=1/(a+(i-1)*h);
%     end
%     x_qr=ls_qr(M,F);
%     t=linspace(a,b,100);
%     f=t.^-1;
%     appro=x_qr(1)*exp(t)+x_qr(2)*sin(t)+x_qr(3)*gamma(t);
%     error(N-1)=norm(f-appro);
% end

% figure
% plot(t,f)
% hold on
% plot(t,appro)
% title ('f(x) and its approximation')
% legend('f(x)','c1*exp(x)+c2*sin(x)+c3*gamma(x)')
% xlabel('x');
% ylabel('f(x)');
% print('-r300','-djpeg');
% 
% figure
% plot(error)
% title ('Error between f(x) and its approximation')
% legend('Error')
% xlabel('N');
% ylabel('Error in discrete L^2 norm');
% print('-r300','-djpeg');