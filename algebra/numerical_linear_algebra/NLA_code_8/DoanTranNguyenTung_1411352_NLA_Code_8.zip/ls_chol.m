function [x]=ls_chol(A,b)
R=chol(A'*A);
% x=linsolve(R,linsolve(R',A'*b));
x=R\(R'\A'*b);