clear all
close all
clc
format long

syms a c; % a stand for n. c stand for index variable i.
u = rand(5,4); % Change u here.
[v,complexity] = gram_schmidt_complex(u) % Gram-Schmidt and complexity.
F = simplify(3 + symsum(c,c,2,a)) % Compute complexity.
disp('Hence: Complexity: O(n^2)');
