clc
close all
clear all
format long

m=7;
n=6;
A=randi(10,m,n);
while (rank(A)<min(m,n))
    A=randi(10,m,n);
end
A
b=randi(10,m,1)
x_chol=ls_chol(A,b)
x_qr=ls_qr(A,b)
x_svd=ls_svd(A,b)

norm(A*x_svd)
norm(b)
norm(A*x_svd-b)



% % % 11.2
% % a=1;
% % b=2;
% % N=2;
% % h=(b-a)/N;
% % M=zeros(N+1,3);
% % F=zeros(N+1,1);
% % for i=1:N+1
% %     for j=1:3
% %         M(i,1)=exp(a+(i-1)*h);
% %         M(i,2)=sin(a+(i-1)*h);
% %         M(i,3)=gamma(a+(i-1)*h);
% %     end
% %     F(i)=1/(a+(i-1)*h);
% % end
% % c=M\F
% % 
% % N=10;
% % h=(b-a)/N;
% % M=zeros(N+1,3);
% % F=zeros(N+1,1);
% % for i=1:N+1
% %     for j=1:3
% %         M(i,1)=exp(a+(i-1)*h);
% %         M(i,2)=sin(a+(i-1)*h);
% %         M(i,3)=gamma(a+(i-1)*h);
% %     end
% %     F(i)=1/(a+(i-1)*h);
% % end
% % 
% % x_chol=ls_chol(M,F)
% % x_qr=ls_qr(M,F)
% % x_svd=ls_svd(M,F)
% % 
% % t=linspace(a,b,100);
% % 
% % f=t.^-1;
% % a=c(1)*exp(t)+c(2)*sin(t)+c(3)*gamma(t);
% % a1=x_chol(1)*exp(t)+x_chol(2)*sin(t)+x_chol(3)*gamma(t);
% % a2=x_qr(1)*exp(t)+x_qr(2)*sin(t)+x_qr(3)*gamma(t);
% % a3=x_svd(1)*exp(t)+x_svd(2)*sin(t)+x_svd(3)*gamma(t);
% % 
% % norm(f-a)
% % norm(f-a1)
% % norm(f-a2)
% % norm(f-a3)
% % 
% % % figure
% % % plot(t,f)
% % % title ('f(x)=1/x')
% % % legend('f(x)')
% % % 
% % % figure
% % % plot(t,a)
% % % title ('Approximation of f(x)')
% % % legend('c1*exp(x)+c2*sin(x)+c3*gamma(x)')
% % 
% % figure
% % plot(t,f)
% % hold on
% % plot(t,a3)
% % title ('f(x) and approximation of f(x)')
% % legend('f(x)','c1*exp(x)+c2*sin(x)+c3*gamma(x)')
