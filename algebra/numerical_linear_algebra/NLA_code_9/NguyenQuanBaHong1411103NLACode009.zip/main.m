clear all
close all
clc
format long

A = [1 2;3 4];
[P,L,U] = GEPV(A)
