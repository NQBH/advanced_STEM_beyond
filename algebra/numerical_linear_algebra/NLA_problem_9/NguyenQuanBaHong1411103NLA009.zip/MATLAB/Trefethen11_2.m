close all
clear all
clc
format long

% Trefethen & Bau, Exercise 11.2.
N = 200;
tol = 1e-17;
for n = 2:N
   % set up least square problem.
   A = zeros(n,3);
   x = linspace(tol,1,n);
   A(:,1) = exp(x');
   A(:,2) = sin(x');
   A(:,3) = gamma(x');
   b = 1./x';
   % solve least square problem.
   [Q,R] = qr(A);
   sol = R\(Q'*b);
   % compute L^2 norm of error.
   error(n) = sqrt(quad(@(z)F(z,sol(1),sol(2),sol(3)),tol,1));
   % compute discrete L^2 norm of error.
   discrete_error(n) = sqrt((norm(b-sol(1)*A(:,1)-sol(2)*A(:,2)-sol(3)*A(:,3)))^2/n);
end
plot(2:N,error(2:N),2:N,discrete_error(2:N));
xlabel('Number of Data Points');
ylabel('Errors');
title('Errors of Least Square Problems');
legend('L^2 norm','discrete L^2 norm');
print('-r300','-djpeg');
