function [Q,R]=mgs_notfullrank(A) % A is the input matrix, which is not fullrank
V=A;
m=size(A,1);
n=size(A,2);
Q=zeros(m,n);
R=zeros(n);
for i=1:n
    R(i,i)=norm(V(:,i));
    if abs(R(i,i))>1e-6
        Q(:,i)=V(:,i)./R(i,i);
    else
        v=ones(m,1);
        Q(:,i)=v;
        for k=1:i
            Q(:,i)=Q(:,i)-dot(Q(:,k),v)*Q(:,k);
        end
        Q(:,i)=Q(:,i)./norm(Q(:,i));
    end
    
    for j=i+1:n
        R(i,j)=dot(Q(:,i),V(:,j));
        V(:,j)=V(:,j)-R(i,j)*Q(:,i);
    end
end
