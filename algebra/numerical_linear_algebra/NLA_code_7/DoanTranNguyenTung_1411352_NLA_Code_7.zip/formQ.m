function [Q]=formQ(W)
[m,n]=size(W);
Q=zeros(m,m);
e=eye(m);
for i=1:m
    x=e(:,i);
    for h=1:n
        k=n-h+1;
        x(k:m,1)=x(k:m,1)-2*W(k:m,k)*W(k:m,k)'*x(k:m,1);
    end
    Q(:,i)=x;
end
