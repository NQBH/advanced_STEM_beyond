function [P,L,U] = GEPV(A)
% Gaussian Elimination with Partial Pivoting.
U = A;
m = size(A,1);
L = eye(m);
P = eye(m);
for k = 1:m-1
    i = k;
    maxu = abs(U(k,k));
    for j = k+1:m
       if (abs(U(j,k)) > maxu) 
          maxu =  abs(U(j,k));
          i = j;
       end
    end
    % Interchange two rows.
    temp = U(k,k:m);
    U(k,k:m) = U(i,k:m);
    U(i,k:m) = temp;
    
    temp = L(k,1:k-1);
    L(k,1:k-1) = L(i,1:k-1);
    L(i,1:k-1) = temp;
    
    temp = P(k,:);
    P(k,:) = P(i,:);
    P(i,:) = temp;
    for j = k+1:m
       L(j,k) = U(j,k)/U(k,k);
       U(j,k:m) = U(j,k:m) - L(j,k)*U(k,k:m)
    end    
end
