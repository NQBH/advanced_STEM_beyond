clear all
close all
clc
format long

A=randi(10,5,4)
[m,n]=size(A);
while rank(A)<n
    A=randi(10,5,4)
    [m,n]=size(A);
end
B=A;
Q=eye(m);
[q,r]=qr(A)

% Using 2x2 Givens rotations matrix
[m,n]=size(A);
Q=eye(m);
for j=1:n
    for i=m:-1:j+1
        a=A(i-1,j);
        b=A(i,j);
        c=a/sqrt((a^2+b^2));
        s=b/sqrt((a^2+b^2));
        M=[c s ; -s c];
        E=eye(m);
        E(i-1:i,i-1:i)=M';
        Q=Q*E;
        A(i-1:i,j:n)=M*A(i-1:i,j:n)
    end
end
Q
R=A
sum(sum(abs(Q*R-B)))
