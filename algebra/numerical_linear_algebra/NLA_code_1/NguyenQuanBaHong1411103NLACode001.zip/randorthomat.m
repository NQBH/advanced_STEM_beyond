function O=randorthomat(n)
A=rand(n);
O=A;
for i=2:n
    for k=1:i-1
        O(i,:)=O(i,:)-dot(O(k,:),A(i,:))*O(k,:)./dot(O(k,:),O(k,:));
    end
end
for i=1:n
    O(i,:)=O(i,:)./norm(O(i,:));
end
