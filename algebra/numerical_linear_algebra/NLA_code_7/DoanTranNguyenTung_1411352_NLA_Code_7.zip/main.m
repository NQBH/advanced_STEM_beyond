clear all
close all
clc
format long

m=5;
n=4;
A=randi(10,m,n)
[W,R]=house(A)
Q=formQ(W)
sum(sum(abs(A-Q*R)))
[q,r]=qr(A)