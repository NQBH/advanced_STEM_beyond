clear all
close all
clc
format long

tic
% % Trefethen 10.2
% a
A = ones(6,5); % m >= n
[W,R] = house(A)
% b
% Test
norm(A - W*R)
toc
