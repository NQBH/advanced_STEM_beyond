function Q = form(W)

[m n] = size(W);
I = eye(m);
Q = I;
for k = 1:n
    Qk = I - 2*W(:,k)*(W(:,k))';
    Q = Q*Qk;
end