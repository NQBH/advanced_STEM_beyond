function [v,complexity] = gram_schmidt_complex(u)
[n m] = size(u);
v = zeros(n,m);
v(1,:) = u(1,:);
complexity = 3;
for i = 2:n
    for j = 1:i-1
        v(i,:) = v(i,:) + ((sum(u(i,:).*v(j,:)))/sum(v(j,:).*v(j,:))).*v(j,:);
        complexity = complexity + 1;
    end
    v(i,:) = u(i,:) - v(i,:);
    complexity = complexity + 1;
end
