function [W,R]=house(A)
[m,n]=size(A);
W=zeros(m,n);
for k=1:n
    x=zeros(m-k+1,1);
    x(:,1)=A(k:m,k);
    v=zeros(m-k+1,n);
    e=eye(m-k+1);
    v(:,k)=sign(x(1,1))*norm(x)*e(:,1)+x;
    v(:,k)=v(:,k)/norm(v(:,k));
    W(k:m,k)=v(:,k);
    A(k:m,k:n)=A(k:m,k:n)-2*v(:,k)*v(:,k)'*A(k:m,k:n);
end
R=A(1:m,:);