format long
clear all
close all
clc

i=0;
for N=1:99
    i=i+1;
    n(i)=N;
    % create matrix of size N with linearly indepentdent rows
    A=randi(N,N);
    while rank(A)<N
          A=randi(N,N);
    end
    % n(i)
    % r=rank(A)
    [V,c(i)]=GS(A);
    fprintf('The number of assignments in the Gram–Schmidt process with n=%d is %d \n',n(i),c(i));
end

figure(1)
plot(n,c)
xlabel('number of linearly indepedent input vectors ')
ylabel('number of assignments')
title('Number of assignments in the Gram–Schmidt process')

% We can check the complexity of the algorithm
syms c n
simplify(1 + symsum(c,c,2,n))
% Therefore, the complexity of the algorithm is O(n^2/2)
t=0:1:100;
figure(2)
plot(t,t.^2./2)
xlabel('n')
ylabel('n^2/2')
title('O(n^2/2)')