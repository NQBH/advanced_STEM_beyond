clear all
close all
clc
format long

syms x
f=x^2-1
[x11,x21]=ISM(f,0,2,20);
fprintf('There is a root in the interval [%.8f,%.8f]\n',x11,x21);
r1=bisection(f,x11,x21,1000);
fprintf('That root is: %.8f\n\n',r1);

f=x^3+exp(x)+sqrt(x)-2016
% vpasolve(f)
[x12,x22]=ISM(f,0,10,20);
fprintf('There is a root in the interval [%.8f,%.8f]\n',x12,x22);
r2=bisection(f,x12,x22,1000);
fprintf('That root is: %.8f\n\n',r2);

