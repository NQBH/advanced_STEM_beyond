function [W,R] = house(A)
[m n] = size(A);
A1 = A;
% Householder QR Factorization
for k = 1:n
    x = A1(k:m,k);
    e1 = zeros(size(x));
    e1(1) = 1;
    v = zeros(size(x));
    v(:,k) = (sign(x(1))*norm(x)).*e1 + x;
    v(:,k) = v(:,k)/norm(v(:,k));
    A1(k:m,k:n) = A1(k:m,k:n) - 2*v(:,k)*v(:,k)'*A1(k:m,k:n);
end
R = A1(1:n,1:n);
W = A*inv(R);
