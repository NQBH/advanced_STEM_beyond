function x = LSSVD(A,b)
% Least Squars via SVD Algorithm.
[U,S,V] = svd(A,0);
w = inv(S)*(U'*b);
x = V*w;
