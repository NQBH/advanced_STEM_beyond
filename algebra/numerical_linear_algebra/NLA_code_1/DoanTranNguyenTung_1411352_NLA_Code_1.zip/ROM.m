% Excercise 3
function U=ROM(n,a,b)
V=rand(n);
U=V;
for i=2:n
    for k=1:i-1
        U(i,:)=U(i,:)-(dot(U(k,:),V(i,:))/dot(U(k,:),U(k,:)))*U(k,:);
    end
end
for i=1:n
    U(i,:)=U(i,:)./norm(U(i,:));
end
