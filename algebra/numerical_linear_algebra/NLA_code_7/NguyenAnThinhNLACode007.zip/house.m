function [W R] = house(A)
[m n] = size(A);
R = A;
I = eye(m);
Q = I
W = zeros(m,n);
for k = 1:n
    x = R(k:m,k)
    e1 = zeros(size(x));
    e1(1) = 1;
    v = zeros(size(x));
    v=sign(x(1))*norm(x)*e1+x;
    v=v/norm(v);
    R(k:m,k:n)=R(k:m,k:n)-2*v*v'*R(k:m,k:n);
end