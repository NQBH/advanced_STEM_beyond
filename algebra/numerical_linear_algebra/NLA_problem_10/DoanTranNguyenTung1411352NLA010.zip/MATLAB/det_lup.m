function detA=det_lup(A)
[m,n]=size(A);
U=A;
detA=1;
for k=1:m-1
    [umax,i]=max(abs(U(k:m,k)));
    i=i+k-1;
    u=U(k,k:m);
    U(k,k:m)=U(i,k:m);
    U(i,k:m)=u;
    if U(k,k)==0
        detA=0;
        return
    end
    detA=-detA;
    detA=detA*U(k,k);
    for j=k+1:m
        U(j,k:m)=U(j,k:m)-U(j,k)/U(k,k)*U(k,k:m);
    end
end
if U(m,m)==0
        detA=0;
        return
else
    detA=detA*U(m,m);
end
