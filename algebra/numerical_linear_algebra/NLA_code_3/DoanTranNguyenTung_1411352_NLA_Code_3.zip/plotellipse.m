function plotellipse(X1,X2,e)
a=max(e(1),e(2));
if a==e(1)
    X=X1;
else
    X=X2;
end
b=min(e(1),e(2));
cosangle=X(1)/a
phi=acos(cosangle) % Orientation (degree) 
num = 100;
theta = linspace(0,2*pi,num);
p(1,:) = a*cos(theta);
p(2,:) = b*sin(theta);
% Rotate to derised angle
phi = phi*pi/180; % deg->rad 
% Rotation matrix: 
Q = [cos(phi) -sin(phi)
    sin(phi)  cos(phi)];
p = Q*p;
plot(p(1,:),p(2,:),'k-','LineWidth',1)
plot(0,0,'k.')

