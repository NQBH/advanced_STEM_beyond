clear all
close all
clc
format long

% Excercise 1
A=[1,3,94;6,4,1;1,9,100]
det(A)-D(A)
A=magic(3)
det(A)-D(A)

% Excercise 2
R=RSM(4,-10,10)

% Excercise 3
O=ROM(4,-10,10)
O'*O
O'*O-O*O'
