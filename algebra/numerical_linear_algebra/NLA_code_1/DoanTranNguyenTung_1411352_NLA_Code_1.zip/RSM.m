% Excercise 2
function A=RSM(n,a,b)
A=a+(b-a).*rand(n);
for i=1:n
    for j=1:n
        if i>j
            A(i,j)=A(j,i);
        end
    end
end
