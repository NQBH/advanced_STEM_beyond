format long
clear all
clc
close all

A=zeros(15,40);
A(2:9,2:3)=ones(8,2);
A(2:9,6:7)=ones(8,2);
A(5:6,4:5)=ones(2,2);

A(3:10,10:11)=ones(8,2);
A(3:4,12:15)=ones(2,4);
A(6:7,12:15)=ones(2,4);
A(9:10,12:15)=ones(2,4);

A(4:11,18:19)=ones(8,2);
A(10:11,20:23)=ones(2,4);

A(5:12,26:27)=ones(8,2);
A(11:12,28:31)=ones(2,4);

A(6:13,34:35)=ones(8,2);
A(6:13,38:39)=ones(8,2);
A(6:7,36:37)=ones(2,2);
A(12:13,36:37)=ones(2,2);

sv=svd(A)
figure
plot(sv)
title('Singular value of A, plotted using "plot"')
figure
semilogy(sv)
title('Singular value of A, plotted using "plot"')
r=rank(A)

figure 
pcolor(A)
% colormap(gray)
axis ij
str=sprintf('Pseudocolor plot of matrix A');
title(str)
    
[U,E,V]=svd(A);
% for i=1:10
%     B=zeros(15,40);
%     for j=1:i
%         B=B+sv(j)*U(:,j)*V(:,j)';     
%     end
%     figure
%     pcolor(B)
%     colormap(gray)
%     axis ij
%     str=sprintf('Pseudocolor plot of mStrix B with i=%d',i);
%     title(str)
% end

B=zeros(15,40);
for j=1:10
    B=B+sv(j)*U(:,j)*V(:,j)';     
end
figure
pcolor(B)
colormap(gray)
axis ij
str=sprintf('Pseudocolor plot of matrix B with i=10');title(str)