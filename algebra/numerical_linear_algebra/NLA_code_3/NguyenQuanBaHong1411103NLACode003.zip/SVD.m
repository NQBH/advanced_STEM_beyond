function SVD = SVD(A)
[U,S,V] = svd(A)
figure(1)
hold on
quiver(0,0,U(1,1),U(1,2))
quiver(0,0,U(2,1),U(2,2))
title('Right singular vectors');
figure(2)
hold on
quiver(0,0,V(1,1),V(2,1))
quiver(0,0,V(1,2),V(2,2))
title('Left singular vectors');
SVD = [];
