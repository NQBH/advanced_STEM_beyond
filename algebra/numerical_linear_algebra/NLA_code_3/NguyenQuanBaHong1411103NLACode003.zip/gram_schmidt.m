function v = gram_schmidt(u)
temp = size(u);
n = temp(1);
m = temp(2);
v = zeros(n,m);
v(1,:) = u(1,:);
for i = 2:n
    s = zeros(1,m);
    for j = 1:i-1
        s = s + ((sum(u(i,:).*v(j,:)))/sum(v(j,:).*v(j,:))).*v(j,:);
    end
    v(i,:) = u(i,:) - s;
end
