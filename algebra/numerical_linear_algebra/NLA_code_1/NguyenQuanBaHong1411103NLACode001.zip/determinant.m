function d=determinant(A)
i=1;j=1;
a=1;
[m,n]=size(A);
tol=1e-6;
while i<=m && j<=n
    if abs(A(i,j))<tol
        c=0;
        for k=i+1:m
            if abs(A(k,j))>tol
                a=-a;
                A([i,k],:)=A([k,i],:);
                c=c+1;
                break
            end
            if c==0 && k==m
                j=j+1;
            end
        end
    else
        for k=i+1:m
            A(k,:)=A(k,:)-(A(k,j)/A(i,j))*A(i,:);
        end
         i=i+1;
         j=j+1;
    end
end
d=1;
for k=1:m
    d=d*A(k,k);
end
d=a*d;
