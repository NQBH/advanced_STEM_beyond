clear all
close all
clc
format long

m=5
A=randi(10,m,m);
while rank(A)<5
    A=randi(10,m,m);
end
A
[L,U,P]=lup(A)
sum(sum(P*A-L*U))