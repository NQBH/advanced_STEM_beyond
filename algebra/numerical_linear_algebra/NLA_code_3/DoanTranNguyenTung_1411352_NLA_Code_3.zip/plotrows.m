function plotrows(U,E)
e(1)=E(1,1);
e(2)=E(2,2);
a=sqrt(e(1)^2+e(2)^2);
figure
axis equal
axis ([-a,a,-a,a])
hold on
arrow([0,0],e(1)*U(1,:),'Length',10,'LineWidth',1);
arrow([0,0],e(2)*U(2,:),'Length',10,'LineWidth',1);
plotellipse(U(1,:),U(2,:),e);
