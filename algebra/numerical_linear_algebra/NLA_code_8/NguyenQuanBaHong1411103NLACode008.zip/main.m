clear all
close all
clc
format long

% Initial Data.
A = rand(5,3);
b = rand(5,1);
% Trefethen Algorithm 11.1. Least Squares via Normal Equations.
x = LSNE(A,b)
% Trefethen Algorithm 11.2. Least Squares via QR Factorization.
x = LSQRF(A,b)
% Trefethen Algorithm 11.3. Least Squares via SVD.
x = LSSVD(A,b)
