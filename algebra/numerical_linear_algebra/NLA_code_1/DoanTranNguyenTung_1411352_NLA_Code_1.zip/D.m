% Excercise 1
function d=D(A)
[m,n]=size(A);
i=1;j=1;a=1;
tol=1e-6;
while i<=m && j<=n
    if abs(A(i,j))>tol
        for k=i+1:m
            A(k,:)=A(k,:)-(A(k,j)/A(i,j))*A(i,:);
        end
         i=i+1;j=j+1;
    else
        for k=i+1:m
            if abs(A(k,j))>tol
                a=-a;
                A([i,k],:)=A([k,i],:);
                break
            end
            j=j+1;
        end
    end
end
d=1;
for k=1:m
    d=d*A(k,k);
end
d=a*d;