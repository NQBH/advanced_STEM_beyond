clear all
close all
clc
format long

M = 6;
N = 9;
A = randi(100,M,N);
% Modified Gram-Schmidt algorithm.
[q,r] = mgs(A)
norm(A - q*r)

