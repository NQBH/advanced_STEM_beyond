clear all
close all
clc
format long

syms x1 x2 x3 e
A=[8 1 0 ; 1 4 e ; 0 e 1]
X=[x1 0 0; 0 x2 0 ; 0 0 x3]
X*A*inv(X)