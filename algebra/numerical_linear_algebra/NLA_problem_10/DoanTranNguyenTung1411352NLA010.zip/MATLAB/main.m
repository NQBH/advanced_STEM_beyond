clear all
close all
clc
format long

m=5
A=randi(10,m,m);
while rank(A)>4
    A=randi(10,m,m);
end
A
% rank(A)
% [L,U,P]=lup(A)
[L,U,P,detA]=detlup(A);
% det(A)-detA
detA2=det_lup(A);
det(A)-detA2
% sum(sum(P*A-L*U))
% [L,U,P]=lu(A)