% Excercise 1
function m=bisection(f,a,b,Nmax)
if abs(subs(f,a))<1e-6
    m=a;
    return
end
if abs(subs(f,b))<1e-6
    m=b;
    return
end
for i=1:Nmax
    m=(a+b)/2;
    if  abs(b-a)/2<1e-6
        break
    end
    if subs(f,a)*subs(f,m)<=0
        b=m;
        continue
    end
    if subs(f,m)*subs(f,b)<=0
        a = m;
        continue
    end
    if i == Nmax
        disp('i=Nmax')
    end
end
    