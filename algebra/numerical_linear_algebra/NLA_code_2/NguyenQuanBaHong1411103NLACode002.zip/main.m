clear all
close all
clc
format long

tic
syms x
f = x^2-1;
[x11,x21] = ISM(f,0,2,20);
fprintf('1 root in [%.8f,%.8f]\n',x11,x21);
% bisecton method
r1 = bisection(f,x11,x21,1000);
fprintf('Root: %.8f\n\n',r1);

f = x^3+exp(x)+sqrt(x)-2016;
% vpasolve(f)
[x12,x22] = ISM(f,0,10,20);
fprintf('1 root in [%.8f,%.8f]\n',x12,x22);
% bisection method
r2 = bisection(f,x12,x22,1000);
fprintf('Root: %.8f\n\n',r2);
toc

