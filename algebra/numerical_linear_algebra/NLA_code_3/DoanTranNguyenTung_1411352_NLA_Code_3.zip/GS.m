function V=GS(U) % U is the matrix of which rows are the input vectors
V=U;
n=size(U,1);
for i=2:n
    for k=1:i-1
        V(i,:)=V(i,:)-dot(V(k,:),U(i,:))*V(k,:)./dot(V(k,:),V(k,:));
    end
end
% % Normalization
% for i=1:n
%     V(i,:)=V(i,:)./norm(V(i,:));
% end