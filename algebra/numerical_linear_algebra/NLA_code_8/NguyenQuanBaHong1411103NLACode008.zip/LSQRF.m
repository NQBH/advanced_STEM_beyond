function x = LSQRF(A,b)
% Least Squares via QR Factorization Algorithm.
[Q,R] = qr(A,0);
x = inv(R)*(Q'*b);
