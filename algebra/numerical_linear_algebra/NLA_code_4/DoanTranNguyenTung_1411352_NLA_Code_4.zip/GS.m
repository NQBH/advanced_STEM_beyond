function [V,c]=GS(U) % U is the matrix of which rows are the input vectors
V=U;
n=size(U,1);
c=1; % c is the number of assignments
for i=2:n
    for k=1:i-1
        V(i,:)=V(i,:)-dot(V(k,:),U(i,:))*V(k,:)./dot(V(k,:),V(k,:));
        c=c+1; 
    end
        V(i,:)=V(i,:)./norm(V(i,:));
        c=c+1; 
end
