function x = LSNE(A,b)
% Least Squares via Normal Equations Algorithm.
R = chol(A'*A);
w = inv(R')*A'*b;
x = inv(R)*w;


