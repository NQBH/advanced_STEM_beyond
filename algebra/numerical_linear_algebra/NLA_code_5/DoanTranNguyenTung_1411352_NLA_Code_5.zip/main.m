format long
clear all
close all
clc

M=6
N=5
A=randi(100,M,N);
while rank(A)<N
    A=randi(M,N);
end
disp('Test a (full rank matrix A with rountine for full rank matrix):')
A
[Qa,Ra]=mgs_fullrank(A);
fprintf('rank(A)=%d\n',rank(A));
[Qa,Ra]=mgs_fullrank(A);
Qa
Ra
fprintf('Q*R=\n');
Qa*Ra
e=sum(sum(abs(Qa*Ra-A)));
sprintf('The total differences between the elements of A and Q*R: %long\n',e);
    
%     B=randi(100,M,N);
%     while rank(B)==N
%           B=randi(M,N);
%     end
%     Qb,Rb]=mgs_fullrank(B);
%     fprintf('rank(B)=%d',rank(B));
%     Qb
%     Rb
%     fprintf('Q*R=%s\n');
%     Qb*Rb
%     f=sum(sum(abs(Qa*Ra-A)));
%     fprintf('the total differences between the elements of B and Q*R:%f',f);
    
% disp('Test b1 (singular matrix B with rountine for full rank matrix):')
% B=[5     5     3     5     4;
%    2     1     2     2     3;
%    1     2     2     1     2;
%    5     2     5     5     2;
%    1     5     4     1     5;
%    0     0     0     0     0]
%    
% [Qb,Rb]=mgs_fullrank(B);
% fprintf('rank(B)=%d\n',rank(B));
% Qb
% Rb
% fprintf('Q*R=\n');
% Qb*Rb
% % f=sum(sum(abs(Qa*Ra-A)));
% % fprintf('The total differences between the elements of B and Q*R: %long\n',f);
%     
% disp('Test b2 (retry test b1 with rountine for singular matrix):')
% [Qc,Rc]=mgs_notfullrank(B);
% Qc
% Rc
% fprintf('Q*R=');
% Qc*Rc
% g=sum(sum(abs(Qc*Rc-B)));
% fprintf('The total differences between the elements of B and Q*R: %long\n',g);