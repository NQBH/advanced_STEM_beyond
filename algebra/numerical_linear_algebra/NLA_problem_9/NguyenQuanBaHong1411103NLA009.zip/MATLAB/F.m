function y = F(z,c1,c2,c3)
y=(1./z-c1*exp(z)-c2*sin(z)-c3*gamma(z)).^2;
