function [L,U,P]=lup(A)
[m,n]=size(A);
U=A;
L=eye(m);
P=eye(m);
for k=1:m-1
    [umax,i]=max(abs(U(k:m,k)));
    i=i+k-1;
    u=U(k,k:m);
    U(k,k:m)=U(i,k:m);
    U(i,k:m)=u;
    l=L(k,1:k-1);
    L(k,1:k-1)=L(i,1:k-1);
    L(i,1:k-1)=l;
    p=P(k,:);
    P(k,:)=P(i,:);
    P(i,:)=p;
    for j=k+1:m
        L(j,k)=U(j,k)/U(k,k);
        U(j,k:m)=U(j,k:m)-L(j,k)*U(k,k:m);
    end
end