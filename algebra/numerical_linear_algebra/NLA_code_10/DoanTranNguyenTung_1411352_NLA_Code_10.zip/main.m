clear all
close all
clc
format long

m=5
A=randi(10,m,m);
while rank(A)<5
    A=randi(10,m,m);
end
A=A'*A;
A
[R]=mychol(A);
R'*R
sum(sum(A-R'*R))