function [x]=ls_qr(A,b)
A2=A;
[m,n]=size(A);
W=zeros(m,n);
for k=1:n
    x=zeros(m-k+1,1);
    x(:,1)=A(k:m,k);
    v=zeros(m-k+1,n);
    e=eye(m-k+1);
    v(:,k)=sign(x(1,1))*norm(x)*e(:,1)+x;
    v(:,k)=v(:,k)/norm(v(:,k));
    W(k:m,k)=v(:,k);
    A(k:m,k:n)=A(k:m,k:n)-2*v(:,k)*v(:,k)'*A(k:m,k:n);
end
R=A(1:m,:);

Q=zeros(m,m);
e=eye(m);
for i=1:m
    x=e(:,i);
    for h=1:n
        k=n-h+1;
        x(k:m,1)=x(k:m,1)-2*W(k:m,k)*W(k:m,k)'*x(k:m,1);
    end
    Q(:,i)=x;
end

% x=linsolve(R,Q'*b);
x=R\Q'*b;