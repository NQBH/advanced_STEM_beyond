function [Q,R] = mgs(A)
m = size(A,1);
n = size(A,2);
V = A;
Q = zeros(m,n);
R = zeros(n);
if rank(A) == min(size(A)) % A is full rank.
    for i = 1:n
        R(i,i) = norm(V(:,i));
        Q(:,i) = V(:,i)./R(i,i);
        for j = i+1:n
           R(i,j) = dot(Q(:,i),V(:,j));
           V(:,j) = V(:,j) - R(i,j)*Q(:,i);
        end
    end
else % A is not full rank
    for i = 1:n
       R(i,i) = norm(V(:,i));
       if abs(R(i,i)) <= 1e-6
           temp = ones(m,1);
           Q(:,i) = temp;
           for k = 1:i
              Q(:,i) = Q(:,i) - dot(Q(:,k),temp)*Q(:,k); 
           end
           Q(:,i) = Q(:,i)./norm(Q(:,i));
       else
           Q(:,i) = V(:,i)./R(i,i);
       end
       for j = i+1:n
           R(i,j) = dot(Q(:,i),V(:,j));
           V(:,j) = V(:,j) - R(i,j)*Q(:,i);
       end
    end
end
